# note with image and some other stuff

here is the **image**:

![test.png](note%20with%20image%20and%20some%20other%20stuff/test.png)

and some **video**:

[https://www.youtube.com/watch?v=wqT1SxhyaKM](https://www.youtube.com/watch?v=wqT1SxhyaKM)

also some song

[https://soundcloud.com/distemperofficial/vremya](https://soundcloud.com/distemperofficial/vremya)

and an empty text file

[plaintext.txt](note%20with%20image%20and%20some%20other%20stuff/plaintext.txt)

```jsx
function i(){
	let cantWrite = "Code";
}
```